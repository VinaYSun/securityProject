package client;

import java.net.Socket;

public class ServerListener extends Thread{

	
	public ServerListener(client client, Socket socket) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run(){
		
	}
}
