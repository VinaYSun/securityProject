package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.Key;
import java.util.HashMap;

public class peerThread extends Thread{

	private BufferedReader in;
	private PrintWriter out;
	private Client client = null;
	private Socket peer = null;
	private Key sessionKey = null;
	private HashMap<String, Key> peerSecretKeyDict = null;
	private String peerName;
	
	public peerThread(Client c, Socket s){
		this.client = c;
		this.peer = s;
		peerSecretKeyDict = new HashMap<String, Key>();

	}
	
	@Override
	public void run() {
		try {
			handleSocket();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//get connection notice, update secret key dict, add new user
	//get logout notice, update secret key dict, delete this user
	
	private void handleSocket() throws IOException {
		
		 in = new BufferedReader(new InputStreamReader(peer.getInputStream()));
         out = new PrintWriter(peer.getOutputStream(), true);
         
         while(true){
        	 
	         String temp = in.readLine();
	         
	         if(temp==null) continue;
	         
	         //get Ticket-to-Me, kab{N2}
	         
	         //verify and SEND Kab{N2, gBmodp}
	         
	         //get Kab{gamodp}
	         
	         //set session key between this invitor A and me
	         /*
	         peerSecretKeyDict = client.getPeerSecretKeyDict();
	         peerSecretKeyDict.put(peerName, sessionKey);
	         client.setPeerSecretKeyDict(peerSecretKeyDict);
	         */
	         
	         System.out.println(temp);
	         System.out.println("local port: " +  peer.getLocalPort() + " port: " +peer.getPort());

	         out.println("Message from a peer: local " +  peer.getLocalPort() + "  Remote " +peer.getPort());
	         
         }
        
	}
}
